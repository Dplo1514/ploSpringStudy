package plo.study.ploSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PloSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PloSpringApplication.class, args);
	}

}
